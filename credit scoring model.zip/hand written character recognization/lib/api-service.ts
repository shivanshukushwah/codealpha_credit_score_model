const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

class ApiService {
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`

    const config: RequestInit = {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    }

    try {
      const response = await fetch(url, config)

      if (!response.ok) {
        let errorMessage = `HTTP error! status: ${response.status}`

        try {
          const errorData = await response.json()
          errorMessage = errorData.error || errorData.details || errorMessage
        } catch {
          // If we can't parse the error response, use the default message
        }

        throw new Error(errorMessage)
      }

      const data = await response.json()
      return data
    } catch (error) {
      if (error instanceof TypeError && error.message.includes("fetch")) {
        throw new Error("Cannot connect to API server. Please ensure the backend is running on http://localhost:5000")
      }

      if (error instanceof Error) {
        throw error
      }

      throw new Error("An unexpected error occurred")
    }
  }

  async getHealth() {
    return this.request<{
      status: string
      model_loaded: boolean
      model_type: string | null
      timestamp: string
      version: string
      uptime: string
    }>("/health")
  }

  async getModelInfo() {
    return this.request<{
      success: boolean
      model_type: string
      features_count: number
      feature_names: string[]
      feature_importance?: Record<string, number>
      metadata: {
        trained_at?: string
        version?: string
        performance_metrics?: Record<string, number>
        training_samples?: number
        features_count?: number
      }
      available_endpoints: string[]
    }>("/model_info")
  }

  async predictCreditworthiness(customerData: any) {
    return this.request<{
      success: boolean
      customer_data: any
      prediction: {
        creditworthy: boolean
        probability_creditworthy: number
        probability_not_creditworthy: number
        risk_score: number
      }
      model_used: string
      recommendation: string
      timestamp: string
      confidence_level: string
    }>("/predict", {
      method: "POST",
      body: JSON.stringify(customerData),
    })
  }

  async batchPredict(customersData: any[]) {
    return this.request<{
      success: boolean
      predictions: Array<{
        customer_id: number
        prediction?: {
          creditworthy: boolean
          probability_creditworthy: number
          risk_score: number
        }
        recommendation?: string
        confidence_level?: string
        error?: string
        status: "success" | "failed"
      }>
      model_used: string
      summary: {
        total_processed: number
        successful_predictions: number
        failed_predictions: number
        success_rate: number
      }
      timestamp: string
    }>("/batch_predict", {
      method: "POST",
      body: JSON.stringify(customersData),
    })
  }

  async retrainModel() {
    return this.request<{
      success: boolean
      message: string
      model_type: string
      timestamp: string
      performance_metrics: Record<string, number>
    }>("/retrain", {
      method: "POST",
    })
  }

  async getSampleRequest() {
    return this.request<{
      success: boolean
      sample_customer_data: any
      usage: string
      curl_example: string
      batch_example: any[]
    }>("/sample_request")
  }

  async getApiDocs() {
    return this.request<{
      title: string
      version: string
      description: string
      base_url: string
      endpoints: Record<string, string>
      model_info: {
        type: string
        features: number
        performance: Record<string, number>
      }
    }>("/docs")
  }

  // Utility method to test connection
  async testConnection(): Promise<boolean> {
    try {
      await this.getHealth()
      return true
    } catch {
      return false
    }
  }
}

export const apiService = new ApiService()

// Export types for use in components
export type HealthStatus = Awaited<ReturnType<typeof apiService.getHealth>>
export type ModelInfo = Awaited<ReturnType<typeof apiService.getModelInfo>>
export type PredictionResult = Awaited<ReturnType<typeof apiService.predictCreditworthiness>>
export type BatchPredictionResult = Awaited<ReturnType<typeof apiService.batchPredict>>
export type RetrainResult = Awaited<ReturnType<typeof apiService.retrainModel>>
export type SampleRequest = Awaited<ReturnType<typeof apiService.getSampleRequest>>