from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import joblib
import pandas as pd
import numpy as np
from credit_scoring_model import CreditScoringModel
import os
import logging
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Configure CORS properly
CORS(app, origins=["http://localhost:3000", "https://*.vercel.app"], 
     methods=["GET", "POST", "OPTIONS"],
     allow_headers=["Content-Type", "Authorization"])

# Global model instance
credit_model = None
model_metadata = {
    "trained_at": None,
    "version": "1.0.0",
    "performance_metrics": {}
}

def initialize_model():
    """Initialize the credit scoring model"""
    global credit_model, model_metadata
    
    try:
        credit_model = CreditScoringModel()
        
        # Check if saved model exists, otherwise train a new one
        if os.path.exists('credit_scoring_model.pkl'):
            try:
                credit_model.load_model('credit_scoring_model.pkl')
                logger.info("✅ Loaded existing model successfully")
                
                # Load metadata if exists
                if os.path.exists('model_metadata.json'):
                    with open('model_metadata.json', 'r') as f:
                        model_metadata.update(json.load(f))
                        
            except Exception as e:
                logger.error(f"❌ Error loading model: {e}")
                logger.info("🔄 Training new model...")
                train_new_model()
        else:
            logger.info("📊 No existing model found, training new one...")
            train_new_model()
            
    except Exception as e:
        logger.error(f"❌ Failed to initialize model: {e}")
        raise

def train_new_model():
    """Train a new model if none exists"""
    global credit_model, model_metadata
    
    try:
        logger.info("🚀 Starting model training...")
        
        # Generate sample data and train model
        df = credit_model.load_and_preprocess_data()
        df_processed = credit_model.feature_engineering(df)
        X, y = credit_model.prepare_features(df_processed)
        
        # Train models
        results = credit_model.train_models(X, y)
        credit_model.hyperparameter_tuning(X, y)
        credit_model.save_model()
        
        # Save metadata
        best_results = results[credit_model.best_model_name]
        model_metadata.update({
            "trained_at": datetime.now().isoformat(),
            "performance_metrics": {
                "accuracy": float(best_results['accuracy']),
                "precision": float(best_results['precision']),
                "recall": float(best_results['recall']),
                "f1_score": float(best_results['f1_score']),
                "roc_auc": float(best_results['roc_auc'])
            },
            "training_samples": len(df),
            "features_count": len(X.columns)
        })
        
        with open('model_metadata.json', 'w') as f:
            json.dump(model_metadata, f, indent=2)
            
        logger.info("✅ Model training completed successfully")
        
    except Exception as e:
        logger.error(f"❌ Model training failed: {e}")
        raise

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

@app.route('/', methods=['GET'])
def root():
    """Root endpoint with API information"""
    return jsonify({
        'message': 'Credit Scoring API',
        'version': model_metadata.get('version', '1.0.0'),
        'status': 'online',
        'endpoints': {
            'health': 'GET /health',
            'predict': 'POST /predict',
            'batch_predict': 'POST /batch_predict',
            'model_info': 'GET /model_info',
            'retrain': 'POST /retrain',
            'sample_request': 'GET /sample_request'
        },
        'documentation': 'Visit /docs for API documentation'
    })

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        model_status = credit_model is not None and hasattr(credit_model, 'best_model')
        
        return jsonify({
            'status': 'healthy' if model_status else 'unhealthy',
            'model_loaded': model_status,
            'model_type': credit_model.best_model_name if model_status else None,
            'timestamp': datetime.now().isoformat(),
            'version': model_metadata.get('version', '1.0.0'),
            'uptime': 'online'
        })
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/predict', methods=['POST', 'OPTIONS'])
def predict_creditworthiness():
    """Predict creditworthiness for a customer"""
    if request.method == 'OPTIONS':
        return '', 200
        
    try:
        # Validate model is loaded
        if not credit_model or not hasattr(credit_model, 'best_model'):
            return jsonify({'error': 'Model not loaded. Please check system status.'}), 503
        
        # Get customer data from request
        customer_data = request.get_json()
        
        if not customer_data:
            return jsonify({'error': 'No customer data provided'}), 400
        
        # Required fields validation
        required_fields = [
            'age', 'income', 'employment_length', 'debt_to_income_ratio',
            'credit_history_length', 'number_of_credit_accounts',
            'payment_history_score', 'credit_utilization', 'number_of_late_payments',
            'loan_amount', 'home_ownership', 'education_level', 'marital_status'
        ]
        
        # Check for missing fields
        missing_fields = [field for field in required_fields if field not in customer_data]
        if missing_fields:
            return jsonify({
                'error': 'Missing required fields',
                'missing_fields': missing_fields,
                'required_fields': required_fields
            }), 400
        
        # Validate data types and ranges
        validation_errors = validate_customer_data(customer_data)
        if validation_errors:
            return jsonify({
                'error': 'Invalid data provided',
                'validation_errors': validation_errors
            }), 400
        
        # Make prediction
        prediction = credit_model.predict_creditworthiness(customer_data)
        
        # Add additional information
        response = {
            'success': True,
            'customer_data': customer_data,
            'prediction': prediction,
            'model_used': credit_model.best_model_name,
            'recommendation': get_recommendation(prediction),
            'timestamp': datetime.now().isoformat(),
            'confidence_level': get_confidence_level(prediction['probability_creditworthy'])
        }
        
        logger.info(f"Prediction made: {prediction['creditworthy']} (confidence: {prediction['probability_creditworthy']:.3f})")
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return jsonify({
            'error': 'Prediction failed',
            'details': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/batch_predict', methods=['POST', 'OPTIONS'])
def batch_predict():
    """Predict creditworthiness for multiple customers"""
    if request.method == 'OPTIONS':
        return '', 200
        
    try:
        if not credit_model or not hasattr(credit_model, 'best_model'):
            return jsonify({'error': 'Model not loaded. Please check system status.'}), 503
            
        customers_data = request.get_json()
        
        if not customers_data or not isinstance(customers_data, list):
            return jsonify({'error': 'Expected a list of customer data'}), 400
        
        if len(customers_data) > 1000:  # Limit batch size
            return jsonify({'error': 'Batch size too large. Maximum 1000 records allowed.'}), 400
        
        predictions = []
        successful_predictions = 0
        failed_predictions = 0
        
        for i, customer_data in enumerate(customers_data):
            try:
                # Validate individual record
                validation_errors = validate_customer_data(customer_data)
                if validation_errors:
                    predictions.append({
                        'customer_id': i,
                        'error': f'Validation failed: {", ".join(validation_errors)}',
                        'status': 'failed'
                    })
                    failed_predictions += 1
                    continue
                
                prediction = credit_model.predict_creditworthiness(customer_data)
                predictions.append({
                    'customer_id': i,
                    'prediction': prediction,
                    'recommendation': get_recommendation(prediction),
                    'confidence_level': get_confidence_level(prediction['probability_creditworthy']),
                    'status': 'success'
                })
                successful_predictions += 1
                
            except Exception as e:
                predictions.append({
                    'customer_id': i,
                    'error': str(e),
                    'status': 'failed'
                })
                failed_predictions += 1
        
        response = {
            'success': True,
            'predictions': predictions,
            'model_used': credit_model.best_model_name,
            'summary': {
                'total_processed': len(predictions),
                'successful_predictions': successful_predictions,
                'failed_predictions': failed_predictions,
                'success_rate': (successful_predictions / len(predictions)) * 100 if predictions else 0
            },
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Batch prediction completed: {successful_predictions}/{len(predictions)} successful")
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Batch prediction error: {e}")
        return jsonify({
            'error': 'Batch prediction failed',
            'details': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/model_info', methods=['GET'])
def get_model_info():
    """Get information about the current model"""
    try:
        if not credit_model:
            return jsonify({'error': 'No model loaded'}), 503
        
        info = {
            'success': True,
            'model_type': credit_model.best_model_name,
            'features_count': len(credit_model.feature_names) if credit_model.feature_names else 0,
            'feature_names': credit_model.feature_names,
            'metadata': model_metadata,
            'available_endpoints': [
                'GET /health - Check API health',
                'POST /predict - Single prediction',
                'POST /batch_predict - Batch predictions',
                'GET /model_info - Model information',
                'POST /retrain - Retrain model',
                'GET /sample_request - Sample request format'
            ]
        }
        
        # Add feature importance if available
        if hasattr(credit_model.best_model, 'feature_importances_') and credit_model.feature_names:
            importance_dict = dict(zip(
                credit_model.feature_names,
                credit_model.best_model.feature_importances_
            ))
            # Sort by importance and convert to list of tuples for JSON serialization
            sorted_importance = sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)
            info['feature_importance'] = dict(sorted_importance[:15])  # Top 15 features
        
        return jsonify(info)
        
    except Exception as e:
        logger.error(f"Model info error: {e}")
        return jsonify({
            'error': 'Failed to get model information',
            'details': str(e)
        }), 500

@app.route('/retrain', methods=['POST', 'OPTIONS'])
def retrain_model():
    """Retrain the model with new data"""
    if request.method == 'OPTIONS':
        return '', 200
        
    try:
        logger.info("🔄 Starting model retraining...")
        
        # This endpoint could accept new training data in the future
        # For now, we'll retrain with generated data
        train_new_model()
        
        return jsonify({
            'success': True,
            'message': 'Model retrained successfully',
            'model_type': credit_model.best_model_name,
            'timestamp': datetime.now().isoformat(),
            'performance_metrics': model_metadata.get('performance_metrics', {})
        })
    
    except Exception as e:
        logger.error(f"Retraining error: {e}")
        return jsonify({
            'error': 'Model retraining failed',
            'details': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/sample_request', methods=['GET'])
def get_sample_request():
    """Get sample request data for testing"""
    sample_data = {
        "age": 35,
        "income": 75000,
        "employment_length": 8,
        "debt_to_income_ratio": 0.3,
        "credit_history_length": 12,
        "number_of_credit_accounts": 5,
        "payment_history_score": 720,
        "credit_utilization": 0.25,
        "number_of_late_payments": 1,
        "loan_amount": 25000,
        "home_ownership": "own",
        "education_level": "bachelor",
        "marital_status": "married"
    }
    
    return jsonify({
        'success': True,
        'sample_customer_data': sample_data,
        'usage': 'POST this data to /predict endpoint',
        'curl_example': f'''curl -X POST http://localhost:5000/predict \\
  -H "Content-Type: application/json" \\
  -d '{json.dumps(sample_data, indent=2)}' ''',
        'batch_example': [sample_data, {**sample_data, "age": 28, "income": 45000}]
    })

def validate_customer_data(data):
    """Validate customer data"""
    errors = []
    
    # Numeric field validations
    numeric_validations = {
        'age': (18, 100),
        'income': (0, 10000000),
        'employment_length': (0, 50),
        'debt_to_income_ratio': (0, 10),
        'credit_history_length': (0, 50),
        'number_of_credit_accounts': (0, 50),
        'payment_history_score': (300, 850),
        'credit_utilization': (0, 5),
        'number_of_late_payments': (0, 100),
        'loan_amount': (0, 10000000)
    }
    
    for field, (min_val, max_val) in numeric_validations.items():
        if field in data:
            try:
                value = float(data[field])
                if value < min_val or value > max_val:
                    errors.append(f"{field} must be between {min_val} and {max_val}")
            except (ValueError, TypeError):
                errors.append(f"{field} must be a valid number")
    
    # Categorical field validations
    categorical_validations = {
        'home_ownership': ['rent', 'own', 'mortgage'],
        'education_level': ['high_school', 'bachelor', 'master', 'phd'],
        'marital_status': ['single', 'married', 'divorced']
    }
    
    for field, allowed_values in categorical_validations.items():
        if field in data and data[field] not in allowed_values:
            errors.append(f"{field} must be one of: {', '.join(allowed_values)}")
    
    return errors

def get_recommendation(prediction):
    """Generate recommendation based on prediction"""
    if prediction['creditworthy']:
        if prediction['probability_creditworthy'] > 0.8:
            return "APPROVE - High confidence in creditworthiness"
        elif prediction['probability_creditworthy'] > 0.6:
            return "APPROVE - Moderate confidence, consider additional verification"
        else:
            return "REVIEW - Low confidence, manual review recommended"
    else:
        if prediction['risk_score'] > 0.8:
            return "REJECT - High risk customer"
        elif prediction['risk_score'] > 0.6:
            return "REJECT - Moderate risk, consider alternative products"
        else:
            return "REVIEW - Borderline case, manual review recommended"

def get_confidence_level(probability):
    """Get confidence level description"""
    if probability > 0.8 or probability < 0.2:
        return "High"
    elif probability > 0.6 or probability < 0.4:
        return "Medium"
    else:
        return "Low"

# Add a simple documentation endpoint
@app.route('/docs', methods=['GET'])
def api_docs():
    """API Documentation"""
    docs = {
        'title': 'Credit Scoring API Documentation',
        'version': model_metadata.get('version', '1.0.0'),
        'description': 'AI-powered credit scoring and risk assessment API',
        'base_url': request.host_url.rstrip('/'),
        'endpoints': {
            'GET /': 'API information and status',
            'GET /health': 'Health check and system status',
            'POST /predict': 'Single customer credit prediction',
            'POST /batch_predict': 'Batch customer credit predictions',
            'GET /model_info': 'Model information and performance metrics',
            'POST /retrain': 'Retrain the model',
            'GET /sample_request': 'Get sample request format',
            'GET /docs': 'This documentation'
        },
        'model_info': {
            'type': credit_model.best_model_name if credit_model else 'Not loaded',
            'features': len(credit_model.feature_names) if credit_model and credit_model.feature_names else 0,
            'performance': model_metadata.get('performance_metrics', {})
        }
    }
    
    return jsonify(docs)

if __name__ == '__main__':
    print("🚀 Starting Credit Scoring API Server...")
    print("=" * 50)
    
    try:
        # Initialize model
        initialize_model()
        
        print("✅ Model initialized successfully")
        print(f"📊 Model type: {credit_model.best_model_name}")
        print(f"🔢 Features: {len(credit_model.feature_names) if credit_model.feature_names else 0}")
        print("=" * 50)
        print("🌐 API Endpoints:")
        print("   GET  /health - Health check")
        print("   POST /predict - Single prediction")
        print("   POST /batch_predict - Batch predictions")
        print("   GET  /model_info - Model information")
        print("   POST /retrain - Retrain model")
        print("   GET  /sample_request - Sample data")
        print("   GET  /docs - API documentation")
        print("=" * 50)
        print("🚀 Starting Flask server on http://localhost:5000")
        print("📖 Visit http://localhost:5000/docs for API documentation")
        print("🔍 Visit http://localhost:5000/health for system status")
        
        # Start the Flask app
        app.run(
            debug=False,  # Set to False for production
            host='0.0.0.0',
            port=5000,
            threaded=True
        )
        
    except Exception as e:
        print(f"❌ Failed to start server: {e}")
        exit(1)
        print("Please check the logs for more details.")    