"""
Complete Credit Scoring Pipeline
This script runs the entire credit scoring pipeline from data generation to API deployment
"""

import sys
import os
from credit_scoring_model import CreditScoringModel
from data_validation import DataValidator
import pandas as pd
import numpy as np

def run_complete_pipeline():
    """Run the complete credit scoring pipeline"""
    
    print("🚀 STARTING COMPLETE CREDIT SCORING PIPELINE")
    print("=" * 60)
    
    # Step 1: Initialize components
    print("\n📊 Step 1: Initializing components...")
    credit_model = CreditScoringModel()
    validator = DataValidator()
    
    # Step 2: Generate and validate data
    print("\n📈 Step 2: Generating sample data...")
    df = credit_model.load_and_preprocess_data()
    print(f"Generated {len(df)} records")
    
    # Step 3: Data validation
    print("\n🔍 Step 3: Validating data quality...")
    validation_summary, clean_df = validator.validate_dataset(df)
    
    # Print validation report
    report = validator.generate_data_quality_report(validation_summary)
    print(report)
    
    if validation_summary['data_quality_score'] < 95:
        print("⚠️  Warning: Data quality score is below 95%")
    else:
        print("✅ Data quality check passed!")
    
    # Step 4: Feature engineering
    print("\n🔧 Step 4: Performing feature engineering...")
    df_processed = credit_model.feature_engineering(clean_df if len(clean_df) > 0 else df)
    print(f"Created {len(df_processed.columns)} features")
    
    # Step 5: Model training
    print("\n🤖 Step 5: Training machine learning models...")
    X, y = credit_model.prepare_features(df_processed)
    
    print(f"Training dataset summary:")
    print(f"  - Total samples: {len(df_processed)}")
    print(f"  - Features: {len(X.columns)}")
    print(f"  - Positive class (creditworthy): {y.sum()} ({y.mean():.2%})")
    print(f"  - Negative class (not creditworthy): {len(y) - y.sum()} ({1 - y.mean():.2%})")
    
    # Train models
    results = credit_model.train_models(X, y)
    
    # Step 6: Model optimization
    print("\n⚙️  Step 6: Optimizing best model...")
    credit_model.hyperparameter_tuning(X, y)
    
    # Step 7: Model evaluation
    print("\n📋 Step 7: Evaluating models...")
    credit_model.evaluate_model(results)
    
    # Step 8: Feature importance analysis
    print("\n🎯 Step 8: Analyzing feature importance...")
    credit_model.feature_importance()
    
    # Step 9: Save model
    print("\n💾 Step 9: Saving trained model...")
    credit_model.save_model('credit_scoring_model.pkl')
    
    # Step 10: Test predictions
    print("\n🧪 Step 10: Testing predictions...")
    
    # Test cases
    test_cases = [
        {
            'name': 'High-quality customer',
            'data': {
                'age': 35,
                'income': 85000,
                'employment_length': 10,
                'debt_to_income_ratio': 0.2,
                'credit_history_length': 15,
                'number_of_credit_accounts': 4,
                'payment_history_score': 780,
                'credit_utilization': 0.15,
                'number_of_late_payments': 0,
                'loan_amount': 30000,
                'home_ownership': 'own',
                'education_level': 'bachelor',
                'marital_status': 'married'
            }
        },
        {
            'name': 'Medium-risk customer',
            'data': {
                'age': 28,
                'income': 45000,
                'employment_length': 3,
                'debt_to_income_ratio': 0.45,
                'credit_history_length': 5,
                'number_of_credit_accounts': 8,
                'payment_history_score': 650,
                'credit_utilization': 0.6,
                'number_of_late_payments': 3,
                'loan_amount': 20000,
                'home_ownership': 'rent',
                'education_level': 'high_school',
                'marital_status': 'single'
            }
        },
        {
            'name': 'High-risk customer',
            'data': {
                'age': 22,
                'income': 25000,
                'employment_length': 1,
                'debt_to_income_ratio': 0.8,
                'credit_history_length': 2,
                'number_of_credit_accounts': 12,
                'payment_history_score': 520,
                'credit_utilization': 0.9,
                'number_of_late_payments': 8,
                'loan_amount': 15000,
                'home_ownership': 'rent',
                'education_level': 'high_school',
                'marital_status': 'single'
            }
        }
    ]
    
    print("\nTesting different customer profiles:")
    print("-" * 50)
    
    for test_case in test_cases:
        prediction = credit_model.predict_creditworthiness(test_case['data'])
        
        print(f"\n{test_case['name']}:")
        print(f"  Creditworthy: {'✅ YES' if prediction['creditworthy'] else '❌ NO'}")
        print(f"  Confidence: {prediction['probability_creditworthy']:.3f}")
        print(f"  Risk Score: {prediction['risk_score']:.3f}")
        
        # Recommendation
        if prediction['creditworthy']:
            if prediction['probability_creditworthy'] > 0.8:
                recommendation = "🟢 APPROVE - High confidence"
            else:
                recommendation = "🟡 APPROVE - Monitor closely"
        else:
            if prediction['risk_score'] > 0.7:
                recommendation = "🔴 REJECT - High risk"
            else:
                recommendation = "🟡 REVIEW - Manual assessment needed"
        
        print(f"  Recommendation: {recommendation}")
    
    # Step 11: Performance summary
    print("\n📊 Step 11: Pipeline Performance Summary")
    print("=" * 50)
    
    best_model_results = results[credit_model.best_model_name]
    
    print(f"Best Model: {credit_model.best_model_name.upper()}")
    print(f"Accuracy: {best_model_results['accuracy']:.4f}")
    print(f"Precision: {best_model_results['precision']:.4f}")
    print(f"Recall: {best_model_results['recall']:.4f}")
    print(f"F1-Score: {best_model_results['f1_score']:.4f}")
    print(f"ROC-AUC: {best_model_results['roc_auc']:.4f}")
    
    # Model interpretation
    print(f"\nModel Interpretation:")
    if best_model_results['precision'] > 0.8:
        print("✅ High precision - Low false positive rate")
    elif best_model_results['precision'] > 0.6:
        print("🟡 Moderate precision - Some false positives expected")
    else:
        print("⚠️  Low precision - High false positive rate")
    
    if best_model_results['recall'] > 0.8:
        print("✅ High recall - Catches most creditworthy customers")
    elif best_model_results['recall'] > 0.6:
        print("🟡 Moderate recall - May miss some creditworthy customers")
    else:
        print("⚠️  Low recall - Missing many creditworthy customers")
    
    # Step 12: API readiness check
    print(f"\n🌐 Step 12: API Readiness Check")
    print("-" * 30)
    
    try:
        # Test model loading
        test_model = CreditScoringModel()
        test_model.load_model('credit_scoring_model.pkl')
        print("✅ Model can be loaded successfully")
        
        # Test prediction
        test_prediction = test_model.predict_creditworthiness(test_cases[0]['data'])
        print("✅ Predictions working correctly")
        
        print("\n🎉 PIPELINE COMPLETED SUCCESSFULLY!")
        print("The model is ready for deployment via the API backend.")
        print("\nTo start the API server, run:")
        print("python api_backend.py")
        
    except Exception as e:
        print(f"❌ Error in API readiness check: {str(e)}")
        return False
    
    return True

def print_usage_instructions():
    """Print instructions for using the credit scoring system"""
    
    print("\n" + "=" * 60)
    print("CREDIT SCORING SYSTEM - USAGE INSTRUCTIONS")
    print("=" * 60)
    
    print("\n🔧 SETUP:")
    print("1. Run this pipeline script to train the model")
    print("2. Start the API server: python api_backend.py")
    print("3. The API will be available at http://localhost:5000")
    
    print("\n🌐 API ENDPOINTS:")
    print("• GET  /health - Check API health")
    print("• GET  /model_info - Get model information")
    print("• GET  /sample_request - Get sample request format")
    print("• POST /predict - Predict single customer")
    print("• POST /batch_predict - Predict multiple customers")
    print("• POST /retrain - Retrain the model")
    
    print("\n📝 SAMPLE API REQUEST:")
    print("curl -X POST http://localhost:5000/predict \\")
    print("  -H 'Content-Type: application/json' \\")
    print("  -d '{")
    print('    "age": 35,')
    print('    "income": 75000,')
    print('    "employment_length": 8,')
    print('    "debt_to_income_ratio": 0.3,')
    print('    "credit_history_length": 12,')
    print('    "number_of_credit_accounts": 5,')
    print('    "payment_history_score": 720,')
    print('    "credit_utilization": 0.25,')
    print('    "number_of_late_payments": 1,')
    print('    "loan_amount": 25000,')
    print('    "home_ownership": "own",')
    print('    "education_level": "bachelor",')
    print('    "marital_status": "married"')
    print("  }'")
    
    print("\n📊 MODEL FEATURES:")
    print("• Multiple algorithms: Logistic Regression, Random Forest, Decision Tree")
    print("• Comprehensive feature engineering")
    print("• Data validation and quality checks")
    print("• Model performance evaluation")
    print("• RESTful API for easy integration")
    print("• Batch prediction support")
    print("• Model retraining capabilities")

if __name__ == "__main__":
    success = run_complete_pipeline()
    
    if success:
        print_usage_instructions()
    else:
        print("\n❌ Pipeline failed. Please check the error messages above.")
        sys.exit(1)
