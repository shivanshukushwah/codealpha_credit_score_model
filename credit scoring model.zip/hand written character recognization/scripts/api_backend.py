from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd
import numpy as np
from credit_scoring_model import CreditScoringModel
import os

app = Flask(__name__)
CORS(app)

# Global model instance
credit_model = None

def initialize_model():
    """Initialize the credit scoring model"""
    global credit_model
    credit_model = CreditScoringModel()
    
    # Check if saved model exists, otherwise train a new one
    if os.path.exists('credit_scoring_model.pkl'):
        try:
            credit_model.load_model('credit_scoring_model.pkl')
            print("Loaded existing model")
        except:
            print("Error loading model, training new one...")
            train_new_model()
    else:
        print("No existing model found, training new one...")
        train_new_model()

def train_new_model():
    """Train a new model if none exists"""
    global credit_model
    
    # Generate sample data and train model
    df = credit_model.load_and_preprocess_data()
    df_processed = credit_model.feature_engineering(df)
    X, y = credit_model.prepare_features(df_processed)
    
    # Train models
    results = credit_model.train_models(X, y)
    credit_model.hyperparameter_tuning(X, y)
    credit_model.save_model()

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': credit_model is not None,
        'model_type': credit_model.best_model_name if credit_model else None
    })

@app.route('/predict', methods=['POST'])
def predict_creditworthiness():
    """Predict creditworthiness for a customer"""
    try:
        # Get customer data from request
        customer_data = request.json
        
        if not customer_data:
            return jsonify({'error': 'No customer data provided'}), 400
        
        # Required fields
        required_fields = [
            'age', 'income', 'employment_length', 'debt_to_income_ratio',
            'credit_history_length', 'number_of_credit_accounts',
            'payment_history_score', 'credit_utilization', 'number_of_late_payments',
            'loan_amount', 'home_ownership', 'education_level', 'marital_status'
        ]
        
        # Check for missing fields
        missing_fields = [field for field in required_fields if field not in customer_data]
        if missing_fields:
            return jsonify({
                'error': 'Missing required fields',
                'missing_fields': missing_fields
            }), 400
        
        # Make prediction
        prediction = credit_model.predict_creditworthiness(customer_data)
        
        # Add additional information
        response = {
            'customer_data': customer_data,
            'prediction': prediction,
            'model_used': credit_model.best_model_name,
            'recommendation': get_recommendation(prediction)
        }
        
        return jsonify(response)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/batch_predict', methods=['POST'])
def batch_predict():
    """Predict creditworthiness for multiple customers"""
    try:
        customers_data = request.json
        
        if not customers_data or not isinstance(customers_data, list):
            return jsonify({'error': 'Expected a list of customer data'}), 400
        
        predictions = []
        for i, customer_data in enumerate(customers_data):
            try:
                prediction = credit_model.predict_creditworthiness(customer_data)
                predictions.append({
                    'customer_id': i,
                    'prediction': prediction,
                    'recommendation': get_recommendation(prediction)
                })
            except Exception as e:
                predictions.append({
                    'customer_id': i,
                    'error': str(e)
                })
        
        return jsonify({
            'predictions': predictions,
            'model_used': credit_model.best_model_name,
            'total_processed': len(predictions)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/model_info', methods=['GET'])
def get_model_info():
    """Get information about the current model"""
    if not credit_model:
        return jsonify({'error': 'No model loaded'}), 500
    
    info = {
        'model_type': credit_model.best_model_name,
        'features_count': len(credit_model.feature_names) if credit_model.feature_names else 0,
        'feature_names': credit_model.feature_names,
        'available_endpoints': [
            '/health',
            '/predict',
            '/batch_predict',
            '/model_info',
            '/retrain'
        ]
    }
    
    # Add feature importance if available
    if hasattr(credit_model.best_model, 'feature_importances_'):
        importance_dict = dict(zip(
            credit_model.feature_names,
            credit_model.best_model.feature_importances_
        ))
        # Sort by importance
        sorted_importance = sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)
        info['feature_importance'] = dict(sorted_importance[:10])  # Top 10 features
    
    return jsonify(info)

@app.route('/retrain', methods=['POST'])
def retrain_model():
    """Retrain the model with new data"""
    try:
        # This endpoint could accept new training data
        # For now, we'll retrain with generated data
        train_new_model()
        
        return jsonify({
            'message': 'Model retrained successfully',
            'model_type': credit_model.best_model_name
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_recommendation(prediction):
    """Generate recommendation based on prediction"""
    if prediction['creditworthy']:
        if prediction['probability_creditworthy'] > 0.8:
            return "APPROVE - High confidence in creditworthiness"
        elif prediction['probability_creditworthy'] > 0.6:
            return "APPROVE - Moderate confidence, consider additional verification"
        else:
            return "REVIEW - Low confidence, manual review recommended"
    else:
        if prediction['risk_score'] > 0.8:
            return "REJECT - High risk customer"
        elif prediction['risk_score'] > 0.6:
            return "REJECT - Moderate risk, consider alternative products"
        else:
            return "REVIEW - Borderline case, manual review recommended"

# Sample request data for testing
@app.route('/sample_request', methods=['GET'])
def get_sample_request():
    """Get sample request data for testing"""
    sample_data = {
        "age": 35,
        "income": 75000,
        "employment_length": 8,
        "debt_to_income_ratio": 0.3,
        "credit_history_length": 12,
        "number_of_credit_accounts": 5,
        "payment_history_score": 720,
        "credit_utilization": 0.25,
        "number_of_late_payments": 1,
        "loan_amount": 25000,
        "home_ownership": "own",
        "education_level": "bachelor",
        "marital_status": "married"
    }
    
    return jsonify({
        "sample_customer_data": sample_data,
        "usage": "POST this data to /predict endpoint"
    })

if __name__ == '__main__':
    print("Initializing Credit Scoring API...")
    initialize_model()
    print("Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=5000)
# Ensure the script runs as a standalone application
if __name__ == '__main__':
    print("Initializing Credit Scoring API...")
    initialize_model()
    print("Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=5000)