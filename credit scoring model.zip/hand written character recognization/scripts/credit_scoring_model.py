import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
warnings.filterwarnings('ignore')

class CreditScoringModel:
    def __init__(self):
        self.models = {
            'logistic_regression': LogisticRegression(random_state=42),
            'random_forest': RandomForestClassifier(random_state=42),
            'decision_tree': DecisionTreeClassifier(random_state=42)
        }
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.best_model = None
        self.best_model_name = None
        self.feature_names = None
        
    def load_and_preprocess_data(self, data_path=None):
        """Load and preprocess the credit data"""
        if data_path:
            df = pd.read_csv(data_path)
        else:
            # Generate sample data for demonstration
            df = self.generate_sample_data()
        
        print(f"Dataset shape: {df.shape}")
        print(f"Dataset info:")
        print(df.info())
        
        return df
    
    def generate_sample_data(self, n_samples=10000):
        """Generate sample credit data for demonstration"""
        np.random.seed(42)
        
        data = {
            'age': np.random.randint(18, 80, n_samples),
            'income': np.random.lognormal(10, 0.5, n_samples),
            'employment_length': np.random.randint(0, 40, n_samples),
            'debt_to_income_ratio': np.random.uniform(0, 1, n_samples),
            'credit_history_length': np.random.randint(0, 30, n_samples),
            'number_of_credit_accounts': np.random.randint(1, 20, n_samples),
            'payment_history_score': np.random.uniform(300, 850, n_samples),
            'credit_utilization': np.random.uniform(0, 1, n_samples),
            'number_of_late_payments': np.random.poisson(2, n_samples),
            'loan_amount': np.random.lognormal(9, 0.8, n_samples),
            'home_ownership': np.random.choice(['rent', 'own', 'mortgage'], n_samples),
            'education_level': np.random.choice(['high_school', 'bachelor', 'master', 'phd'], n_samples),
            'marital_status': np.random.choice(['single', 'married', 'divorced'], n_samples)
        }
        
        df = pd.DataFrame(data)
        
        # Create target variable based on logical rules
        risk_score = (
            (df['payment_history_score'] / 850) * 0.35 +
            (1 - df['debt_to_income_ratio']) * 0.25 +
            (df['credit_history_length'] / 30) * 0.15 +
            (1 - df['credit_utilization']) * 0.15 +
            (1 - df['number_of_late_payments'] / 10) * 0.10
        )
        
        # Add some noise and create binary target
        risk_score += np.random.normal(0, 0.1, n_samples)
        df['creditworthy'] = (risk_score > 0.6).astype(int)
        
        return df
    
    def feature_engineering(self, df):
        """Perform feature engineering on the dataset"""
        df_processed = df.copy()
        
        # Create new features
        df_processed['income_to_loan_ratio'] = df_processed['income'] / (df_processed['loan_amount'] + 1)
        df_processed['age_income_interaction'] = df_processed['age'] * df_processed['income'] / 1000000
        df_processed['credit_score_normalized'] = df_processed['payment_history_score'] / 850
        df_processed['total_debt_burden'] = df_processed['debt_to_income_ratio'] * df_processed['income']
        
        # Binning continuous variables
        df_processed['age_group'] = pd.cut(df_processed['age'], 
                                         bins=[0, 25, 35, 50, 100], 
                                         labels=['young', 'adult', 'middle_aged', 'senior'])
        
        df_processed['income_bracket'] = pd.qcut(df_processed['income'], 
                                               q=5, 
                                               labels=['very_low', 'low', 'medium', 'high', 'very_high'])
        
        # Handle categorical variables
        categorical_columns = ['home_ownership', 'education_level', 'marital_status', 'age_group', 'income_bracket']
        
        for col in categorical_columns:
            if col not in self.label_encoders:
                self.label_encoders[col] = LabelEncoder()
                df_processed[col] = self.label_encoders[col].fit_transform(df_processed[col].astype(str))
            else:
                df_processed[col] = self.label_encoders[col].transform(df_processed[col].astype(str))
        
        return df_processed
    
    def prepare_features(self, df):
        """Prepare features for model training"""
        # Select features (excluding target variable)
        feature_columns = [col for col in df.columns if col != 'creditworthy']
        X = df[feature_columns]
        y = df['creditworthy']
        
        self.feature_names = feature_columns
        
        return X, y
    
    def train_models(self, X, y):
        """Train multiple models and compare performance"""
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        results = {}
        
        print("Training models...")
        print("=" * 50)
        
        for name, model in self.models.items():
            print(f"\nTraining {name}...")
            
            # Train model
            if name == 'logistic_regression':
                model.fit(X_train_scaled, y_train)
                y_pred = model.predict(X_test_scaled)
                y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
            else:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                y_pred_proba = model.predict_proba(X_test)[:, 1]
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred)
            recall = recall_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred)
            roc_auc = roc_auc_score(y_test, y_pred_proba)
            
            results[name] = {
                'model': model,
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'roc_auc': roc_auc,
                'y_test': y_test,
                'y_pred': y_pred,
                'y_pred_proba': y_pred_proba
            }
            
            print(f"Accuracy: {accuracy:.4f}")
            print(f"Precision: {precision:.4f}")
            print(f"Recall: {recall:.4f}")
            print(f"F1-Score: {f1:.4f}")
            print(f"ROC-AUC: {roc_auc:.4f}")
        
        # Select best model based on F1-score
        best_model_name = max(results.keys(), key=lambda x: results[x]['f1_score'])
        self.best_model = results[best_model_name]['model']
        self.best_model_name = best_model_name
        
        print(f"\nBest model: {best_model_name} (F1-Score: {results[best_model_name]['f1_score']:.4f})")
        
        return results
    
    def hyperparameter_tuning(self, X, y):
        """Perform hyperparameter tuning for the best model"""
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        
        if self.best_model_name == 'random_forest':
            param_grid = {
                'n_estimators': [100, 200, 300],
                'max_depth': [10, 20, None],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            }
            
            grid_search = GridSearchCV(
                RandomForestClassifier(random_state=42),
                param_grid,
                cv=5,
                scoring='f1',
                n_jobs=-1
            )
            
            grid_search.fit(X_train, y_train)
            self.best_model = grid_search.best_estimator_
            
            print(f"Best parameters: {grid_search.best_params_}")
            print(f"Best cross-validation score: {grid_search.best_score_:.4f}")
    
    def evaluate_model(self, results):
        """Generate detailed evaluation report"""
        print("\n" + "="*60)
        print("DETAILED MODEL EVALUATION")
        print("="*60)
        
        for name, result in results.items():
            print(f"\n{name.upper()} RESULTS:")
            print("-" * 30)
            print(classification_report(result['y_test'], result['y_pred']))
            
            # Confusion Matrix
            cm = confusion_matrix(result['y_test'], result['y_pred'])
            print(f"Confusion Matrix:")
            print(cm)
    
    def plot_roc_curves(self, results):
        """Plot ROC curves for all models"""
        plt.figure(figsize=(10, 8))
        
        for name, result in results.items():
            fpr, tpr, _ = roc_curve(result['y_test'], result['y_pred_proba'])
            plt.plot(fpr, tpr, label=f"{name} (AUC = {result['roc_auc']:.3f})")
        
        plt.plot([0, 1], [0, 1], 'k--', label='Random')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curves Comparison')
        plt.legend()
        plt.grid(True)
        plt.show()
    
    def feature_importance(self):
        """Display feature importance for tree-based models"""
        if hasattr(self.best_model, 'feature_importances_'):
            importance_df = pd.DataFrame({
                'feature': self.feature_names,
                'importance': self.best_model.feature_importances_
            }).sort_values('importance', ascending=False)
            
            print("\nFeature Importance:")
            print("-" * 30)
            print(importance_df.head(10))
            
            # Plot feature importance
            plt.figure(figsize=(10, 6))
            sns.barplot(data=importance_df.head(10), x='importance', y='feature')
            plt.title('Top 10 Feature Importance')
            plt.tight_layout()
            plt.show()
    
    def save_model(self, filepath='credit_scoring_model.pkl'):
        """Save the trained model and preprocessors"""
        model_data = {
            'model': self.best_model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'feature_names': self.feature_names,
            'model_name': self.best_model_name
        }
        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath='credit_scoring_model.pkl'):
        """Load a saved model"""
        model_data = joblib.load(filepath)
        self.best_model = model_data['model']
        self.scaler = model_data['scaler']
        self.label_encoders = model_data['label_encoders']
        self.feature_names = model_data['feature_names']
        self.best_model_name = model_data['model_name']
        print(f"Model loaded from {filepath}")
    
    def predict_creditworthiness(self, customer_data):
        """Predict creditworthiness for new customer data"""
        if self.best_model is None:
            raise ValueError("No trained model available. Please train a model first.")
        
        # Convert to DataFrame if it's a dictionary
        if isinstance(customer_data, dict):
            df = pd.DataFrame([customer_data])
        else:
            df = customer_data.copy()
        
        # Apply feature engineering
        df_processed = self.feature_engineering(df)
        
        # Ensure all required features are present
        for feature in self.feature_names:
            if feature not in df_processed.columns:
                df_processed[feature] = 0  # Default value for missing features
        
        # Select and order features
        X = df_processed[self.feature_names]
        
        # Scale features if using logistic regression
        if self.best_model_name == 'logistic_regression':
            X_scaled = self.scaler.transform(X)
            prediction = self.best_model.predict(X_scaled)[0]
            probability = self.best_model.predict_proba(X_scaled)[0]
        else:
            prediction = self.best_model.predict(X)[0]
            probability = self.best_model.predict_proba(X)[0]
        
        return {
            'creditworthy': bool(prediction),
            'probability_not_creditworthy': float(probability[0]),
            'probability_creditworthy': float(probability[1]),
            'risk_score': float(1 - probability[1])  # Higher score = higher risk
        }

def main():
    # Initialize the credit scoring model
    credit_model = CreditScoringModel()
    
    # Load and preprocess data
    print("Loading and preprocessing data...")
    df = credit_model.load_and_preprocess_data()
    
    # Feature engineering
    print("\nPerforming feature engineering...")
    df_processed = credit_model.feature_engineering(df)
    
    # Prepare features
    X, y = credit_model.prepare_features(df_processed)
    
    print(f"\nDataset summary:")
    print(f"Total samples: {len(df_processed)}")
    print(f"Features: {len(X.columns)}")
    print(f"Creditworthy: {y.sum()} ({y.mean():.2%})")
    print(f"Not creditworthy: {len(y) - y.sum()} ({1 - y.mean():.2%})")
    
    # Train models
    results = credit_model.train_models(X, y)
    
    # Hyperparameter tuning
    print("\nPerforming hyperparameter tuning...")
    credit_model.hyperparameter_tuning(X, y)
    
    # Evaluate models
    credit_model.evaluate_model(results)
    
    # Feature importance
    credit_model.feature_importance()
    
    # Save model
    credit_model.save_model()
    
    # Example prediction
    print("\n" + "="*60)
    print("EXAMPLE PREDICTION")
    print("="*60)
    
    sample_customer = {
        'age': 35,
        'income': 75000,
        'employment_length': 8,
        'debt_to_income_ratio': 0.3,
        'credit_history_length': 12,
        'number_of_credit_accounts': 5,
        'payment_history_score': 720,
        'credit_utilization': 0.25,
        'number_of_late_payments': 1,
        'loan_amount': 25000,
        'home_ownership': 'own',
        'education_level': 'bachelor',
        'marital_status': 'married'
    }
    
    prediction = credit_model.predict_creditworthiness(sample_customer)
    print(f"Sample customer prediction:")
    print(f"Creditworthy: {prediction['creditworthy']}")
    print(f"Probability of being creditworthy: {prediction['probability_creditworthy']:.3f}")
    print(f"Risk score: {prediction['risk_score']:.3f}")

if __name__ == "__main__":
    main()
# This script implements a credit scoring model using various machine learning techniques.
# It includes data loading, preprocessing, feature engineering, model training, evaluation, and prediction functionalities.
# The model can be trained on sample data or real-world datasets, and it supports hyperparameter tuning for improved performance.
# The final model can be saved and loaded for future predictions.   