import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
import warnings

class DataValidator:
    """Data validation and quality checks for credit scoring data"""
    
    def __init__(self):
        self.validation_rules = {
            'age': {'min': 18, 'max': 100, 'type': 'numeric'},
            'income': {'min': 0, 'max': 10000000, 'type': 'numeric'},
            'employment_length': {'min': 0, 'max': 50, 'type': 'numeric'},
            'debt_to_income_ratio': {'min': 0, 'max': 10, 'type': 'numeric'},
            'credit_history_length': {'min': 0, 'max': 50, 'type': 'numeric'},
            'number_of_credit_accounts': {'min': 0, 'max': 50, 'type': 'numeric'},
            'payment_history_score': {'min': 300, 'max': 850, 'type': 'numeric'},
            'credit_utilization': {'min': 0, 'max': 5, 'type': 'numeric'},
            'number_of_late_payments': {'min': 0, 'max': 100, 'type': 'numeric'},
            'loan_amount': {'min': 0, 'max': 10000000, 'type': 'numeric'},
            'home_ownership': {'allowed_values': ['rent', 'own', 'mortgage'], 'type': 'categorical'},
            'education_level': {'allowed_values': ['high_school', 'bachelor', 'master', 'phd'], 'type': 'categorical'},
            'marital_status': {'allowed_values': ['single', 'married', 'divorced'], 'type': 'categorical'}
        }
    
    def validate_single_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Validate a single customer record"""
        validation_result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'cleaned_record': record.copy()
        }
        
        for field, rules in self.validation_rules.items():
            if field not in record:
                validation_result['errors'].append(f"Missing required field: {field}")
                validation_result['is_valid'] = False
                continue
            
            value = record[field]
            
            # Type validation
            if rules['type'] == 'numeric':
                try:
                    value = float(value)
                    validation_result['cleaned_record'][field] = value
                except (ValueError, TypeError):
                    validation_result['errors'].append(f"Field {field} must be numeric, got {type(value)}")
                    validation_result['is_valid'] = False
                    continue
                
                # Range validation
                if 'min' in rules and value < rules['min']:
                    validation_result['errors'].append(f"Field {field} ({value}) is below minimum ({rules['min']})")
                    validation_result['is_valid'] = False
                
                if 'max' in rules and value > rules['max']:
                    validation_result['errors'].append(f"Field {field} ({value}) is above maximum ({rules['max']})")
                    validation_result['is_valid'] = False
            
            elif rules['type'] == 'categorical':
                if 'allowed_values' in rules and value not in rules['allowed_values']:
                    validation_result['errors'].append(
                        f"Field {field} has invalid value '{value}'. Allowed values: {rules['allowed_values']}"
                    )
                    validation_result['is_valid'] = False
        
        # Business logic validation
        self._validate_business_rules(validation_result)
        
        return validation_result
    
    def _validate_business_rules(self, validation_result: Dict[str, Any]):
        """Apply business logic validation rules"""
        record = validation_result['cleaned_record']
        
        # Debt-to-income ratio should be reasonable
        if 'debt_to_income_ratio' in record and record['debt_to_income_ratio'] > 1:
            validation_result['warnings'].append(
                f"High debt-to-income ratio: {record['debt_to_income_ratio']:.2f}"
            )
        
        # Credit utilization should be reasonable
        if 'credit_utilization' in record and record['credit_utilization'] > 1:
            validation_result['warnings'].append(
                f"High credit utilization: {record['credit_utilization']:.2f}"
            )
        
        # Employment length vs age consistency
        if ('age' in record and 'employment_length' in record and 
            record['employment_length'] > record['age'] - 16):
            validation_result['warnings'].append(
                "Employment length seems inconsistent with age"
            )
        
        # Credit history length vs age consistency
        if ('age' in record and 'credit_history_length' in record and 
            record['credit_history_length'] > record['age'] - 18):
            validation_result['warnings'].append(
                "Credit history length seems inconsistent with age"
            )
    
    def validate_dataset(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Validate an entire dataset"""
        validation_summary = {
            'total_records': len(df),
            'valid_records': 0,
            'invalid_records': 0,
            'records_with_warnings': 0,
            'common_errors': {},
            'data_quality_score': 0,
            'field_completeness': {},
            'field_statistics': {}
        }
        
        valid_records = []
        all_errors = []
        
        for idx, row in df.iterrows():
            record_dict = row.to_dict()
            validation_result = self.validate_single_record(record_dict)
            
            if validation_result['is_valid']:
                validation_summary['valid_records'] += 1
                valid_records.append(validation_result['cleaned_record'])
            else:
                validation_summary['invalid_records'] += 1
                all_errors.extend(validation_result['errors'])
            
            if validation_result['warnings']:
                validation_summary['records_with_warnings'] += 1
        
        # Calculate data quality score
        validation_summary['data_quality_score'] = (
            validation_summary['valid_records'] / validation_summary['total_records']
        ) * 100
        
        # Count common errors
        for error in all_errors:
            error_type = error.split(':')[0] if ':' in error else error
            validation_summary['common_errors'][error_type] = (
                validation_summary['common_errors'].get(error_type, 0) + 1
            )
        
        # Field completeness analysis
        for column in df.columns:
            non_null_count = df[column].notna().sum()
            validation_summary['field_completeness'][column] = {
                'completeness_rate': (non_null_count / len(df)) * 100,
                'missing_count': len(df) - non_null_count
            }
        
        # Field statistics for numeric columns
        numeric_columns = df.select_dtypes(include=[np.number]).columns
        for column in numeric_columns:
            if column in df.columns:
                validation_summary['field_statistics'][column] = {
                    'mean': float(df[column].mean()) if not df[column].isna().all() else None,
                    'median': float(df[column].median()) if not df[column].isna().all() else None,
                    'std': float(df[column].std()) if not df[column].isna().all() else None,
                    'min': float(df[column].min()) if not df[column].isna().all() else None,
                    'max': float(df[column].max()) if not df[column].isna().all() else None,
                    'outliers_count': self._count_outliers(df[column])
                }
        
        return validation_summary, pd.DataFrame(valid_records) if valid_records else pd.DataFrame()
    
    def _count_outliers(self, series: pd.Series) -> int:
        """Count outliers using IQR method"""
        if series.isna().all():
            return 0
        
        Q1 = series.quantile(0.25)
        Q3 = series.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        outliers = series[(series < lower_bound) | (series > upper_bound)]
        return len(outliers)
    
    def generate_data_quality_report(self, validation_summary: Dict[str, Any]) -> str:
        """Generate a human-readable data quality report"""
        report = []
        report.append("=" * 60)
        report.append("DATA QUALITY REPORT")
        report.append("=" * 60)
        
        # Overall summary
        report.append(f"\nOVERALL SUMMARY:")
        report.append(f"Total Records: {validation_summary['total_records']}")
        report.append(f"Valid Records: {validation_summary['valid_records']}")
        report.append(f"Invalid Records: {validation_summary['invalid_records']}")
        report.append(f"Records with Warnings: {validation_summary['records_with_warnings']}")
        report.append(f"Data Quality Score: {validation_summary['data_quality_score']:.2f}%")
        
        # Field completeness
        report.append(f"\nFIELD COMPLETENESS:")
        for field, stats in validation_summary['field_completeness'].items():
            report.append(f"  {field}: {stats['completeness_rate']:.1f}% complete "
                         f"({stats['missing_count']} missing)")
        
        # Common errors
        if validation_summary['common_errors']:
            report.append(f"\nCOMMON ERRORS:")
            for error, count in sorted(validation_summary['common_errors'].items(), 
                                     key=lambda x: x[1], reverse=True):
                report.append(f"  {error}: {count} occurrences")
        
        # Field statistics
        if validation_summary['field_statistics']:
            report.append(f"\nFIELD STATISTICS:")
            for field, stats in validation_summary['field_statistics'].items():
                if stats['mean'] is not None:
                    report.append(f"  {field}:")
                    report.append(f"    Mean: {stats['mean']:.2f}")
                    report.append(f"    Median: {stats['median']:.2f}")
                    report.append(f"    Std Dev: {stats['std']:.2f}")
                    report.append(f"    Range: {stats['min']:.2f} - {stats['max']:.2f}")
                    report.append(f"    Outliers: {stats['outliers_count']}")
        
        return "\n".join(report)

def main():
    """Test the data validator"""
    from credit_scoring_model import CreditScoringModel
    
    # Create sample data
    credit_model = CreditScoringModel()
    df = credit_model.generate_sample_data(1000)
    
    # Add some invalid data for testing
    df.loc[0, 'age'] = -5  # Invalid age
    df.loc[1, 'income'] = -1000  # Invalid income
    df.loc[2, 'home_ownership'] = 'invalid_value'  # Invalid categorical
    df.loc[3, 'payment_history_score'] = 1000  # Out of range
    
    # Initialize validator
    validator = DataValidator()
    
    # Validate dataset
    print("Validating dataset...")
    validation_summary, clean_df = validator.validate_dataset(df)
    
    # Generate report
    report = validator.generate_data_quality_report(validation_summary)
    print(report)
    
    # Test single record validation
    print("\n" + "="*60)
    print("SINGLE RECORD VALIDATION TEST")
    print("="*60)
    
    test_record = {
        'age': 35,
        'income': 75000,
        'employment_length': 8,
        'debt_to_income_ratio': 0.3,
        'credit_history_length': 12,
        'number_of_credit_accounts': 5,
        'payment_history_score': 720,
        'credit_utilization': 0.25,
        'number_of_late_payments': 1,
        'loan_amount': 25000,
        'home_ownership': 'own',
        'education_level': 'bachelor',
        'marital_status': 'married'
    }
    
    result = validator.validate_single_record(test_record)
    print(f"Valid: {result['is_valid']}")
    print(f"Errors: {result['errors']}")
    print(f"Warnings: {result['warnings']}")

if __name__ == "__main__":
    main()
#     app.run(debug=True)
#     print("Starting Flask server...")
#     app.run(debug=True, host='0.0.0.0', port=5000)