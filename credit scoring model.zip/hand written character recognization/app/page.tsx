"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Activity, Users, TrendingUp, AlertCircle, CheckCircle, XCircle, Wifi, WifiOff } from "lucide-react"
import CreditScoringForm from "@/components/credit-scoring-form"
import BatchPrediction from "@/components/batch-prediction"
import ModelInfo from "@/components/model-info"
import PredictionHistory from "@/components/prediction-history"
import { apiService } from "@/lib/api-service"

interface HealthStatus {
  status: string
  model_loaded: boolean
  model_type: string | null
  timestamp: string
  version: string
}

interface ModelInformation {
  model_type: string
  features_count: number
  feature_names: string[]
  feature_importance?: Record<string, number>
  metadata: {
    trained_at?: string
    performance_metrics?: Record<string, number>
    training_samples?: number
  }
}

export default function Dashboard() {
  const [healthStatus, setHealthStatus] = useState<HealthStatus | null>(null)
  const [modelInfo, setModelInfo] = useState<ModelInformation | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [connectionStatus, setConnectionStatus] = useState<"connected" | "disconnected" | "checking">("checking")

  useEffect(() => {
    loadDashboardData()

    // Set up periodic health checks
    const healthCheckInterval = setInterval(checkConnection, 30000) // Every 30 seconds

    return () => clearInterval(healthCheckInterval)
  }, [])

  const checkConnection = async () => {
    try {
      await apiService.getHealth()
      setConnectionStatus("connected")
    } catch (err) {
      setConnectionStatus("disconnected")
    }
  }

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      setError(null)
      setConnectionStatus("checking")

      const [health, info] = await Promise.all([apiService.getHealth(), apiService.getModelInfo()])

      setHealthStatus(health)
      setModelInfo(info)
      setConnectionStatus("connected")
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to load dashboard data"
      setError(errorMessage)
      setConnectionStatus("disconnected")

      // If it's a connection error, provide more specific guidance
      if (errorMessage.includes("fetch")) {
        setError(
          "Cannot connect to the API server. Please ensure the Python backend is running on http://localhost:5000",
        )
      }
    } finally {
      setLoading(false)
    }
  }

  const handleRetrain = async () => {
    try {
      setLoading(true)
      const result = await apiService.retrainModel()

      // Show success message and reload data
      await loadDashboardData()

      // You could add a toast notification here
      console.log("Model retrained successfully:", result)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to retrain model")
    } finally {
      setLoading(false)
    }
  }

  // Connection status indicator
  const ConnectionIndicator = () => (
    <div className="flex items-center gap-2">
      {connectionStatus === "connected" ? (
        <>
          <Wifi className="h-4 w-4 text-green-500" />
          <span className="text-sm text-green-600">Connected</span>
        </>
      ) : connectionStatus === "disconnected" ? (
        <>
          <WifiOff className="h-4 w-4 text-red-500" />
          <span className="text-sm text-red-600">Disconnected</span>
        </>
      ) : (
        <>
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
          <span className="text-sm text-gray-600">Checking...</span>
        </>
      )}
    </div>
  )

  if (loading && !healthStatus) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
          <p className="mt-2 text-sm text-gray-500">Connecting to API server...</p>
        </div>
      </div>
    )
  }

  if (error && !healthStatus) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <AlertCircle className="h-5 w-5" />
              Connection Error
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>

            <div className="space-y-2 text-sm text-gray-600">
              <p>
                <strong>To fix this issue:</strong>
              </p>
              <ol className="list-decimal list-inside space-y-1 ml-2">
                <li>Make sure Python backend is running</li>
                <li>Navigate to your backend directory</li>
                <li>
                  Run: <code className="bg-gray-100 px-1 rounded">python enhanced_api_backend.py</code>
                </li>
                <li>Ensure it's running on http://localhost:5000</li>
              </ol>
            </div>

            <Button onClick={loadDashboardData} className="w-full">
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Credit Scoring System</h1>
              <p className="text-gray-600">AI-powered creditworthiness assessment</p>
            </div>
            <div className="flex items-center gap-4">
              <ConnectionIndicator />
              <Badge
                variant={healthStatus?.status === "healthy" ? "default" : "destructive"}
                className="flex items-center gap-1"
              >
                {healthStatus?.status === "healthy" ? (
                  <CheckCircle className="h-3 w-3" />
                ) : (
                  <XCircle className="h-3 w-3" />
                )}
                {healthStatus?.status || "Unknown"}
              </Badge>
              <Button onClick={handleRetrain} variant="outline" disabled={loading || connectionStatus !== "connected"}>
                {loading ? "Retraining..." : "Retrain Model"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Connection Warning */}
      {connectionStatus === "disconnected" && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              Connection to API server lost. Some features may not work properly.
              <Button variant="link" className="p-0 h-auto text-yellow-800 underline ml-1" onClick={loadDashboardData}>
                Retry connection
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Model Status</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthStatus?.model_loaded ? "Active" : "Inactive"}</div>
              <p className="text-xs text-muted-foreground">
                {modelInfo?.model_type?.replace("_", " ").toUpperCase() || "No model loaded"}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Features</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{modelInfo?.features_count || 0}</div>
              <p className="text-xs text-muted-foreground">Input features</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Performance</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {modelInfo?.metadata?.performance_metrics?.f1_score
                  ? `${(modelInfo.metadata.performance_metrics.f1_score * 100).toFixed(1)}%`
                  : "N/A"}
              </div>
              <p className="text-xs text-muted-foreground">F1 Score</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">API Status</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {connectionStatus === "connected" ? "Online" : "Offline"}
              </div>
              <p className="text-xs text-muted-foreground">v{healthStatus?.version || "1.0.0"}</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="predict" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="predict">Single Prediction</TabsTrigger>
            <TabsTrigger value="batch">Batch Prediction</TabsTrigger>
            <TabsTrigger value="model">Model Info</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="predict" className="space-y-6">
            <CreditScoringForm connectionStatus={connectionStatus} />
          </TabsContent>

          <TabsContent value="batch" className="space-y-6">
            <BatchPrediction connectionStatus={connectionStatus} />
          </TabsContent>

          <TabsContent value="model" className="space-y-6">
            <ModelInfo modelInfo={modelInfo} />
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <PredictionHistory />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
// Note: Ensure you have the necessary components (CreditScoringForm, BatchPrediction, ModelInfo, PredictionHistory) and styles set up in your project.
// The apiService should handle API calls to your backend, including getHealth, getModelInfo, retrainModel, etc.
// Adjust the imports and component structure as needed based on your project setup.    