"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle, XCircle, User, DollarSign, CreditCard, Home, Loader2 } from "lucide-react"
import { apiService, type PredictionResult } from "@/lib/api-service"

interface CustomerData {
  age: number
  income: number
  employment_length: number
  debt_to_income_ratio: number
  credit_history_length: number
  number_of_credit_accounts: number
  payment_history_score: number
  credit_utilization: number
  number_of_late_payments: number
  loan_amount: number
  home_ownership: string
  education_level: string
  marital_status: string
}

interface CreditScoringFormProps {
  connectionStatus: "connected" | "disconnected" | "checking"
}

export default function CreditScoringForm({ connectionStatus }: CreditScoringFormProps) {
  const [formData, setFormData] = useState<CustomerData>({
    age: 35,
    income: 75000,
    employment_length: 8,
    debt_to_income_ratio: 0.3,
    credit_history_length: 12,
    number_of_credit_accounts: 5,
    payment_history_score: 720,
    credit_utilization: 0.25,
    number_of_late_payments: 1,
    loan_amount: 25000,
    home_ownership: "own",
    education_level: "bachelor",
    marital_status: "married",
  })

  const [prediction, setPrediction] = useState<PredictionResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleInputChange = (field: keyof CustomerData, value: string | number) => {
    setFormData((prev) => ({
      ...prev,
      [field]: typeof value === "string" && !isNaN(Number(value)) ? Number(value) : value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (connectionStatus !== "connected") {
      setError("Cannot make prediction: API server is not connected")
      return
    }

    setLoading(true)
    setError(null)
    setPrediction(null)

    try {
      const result = await apiService.predictCreditworthiness(formData)
      setPrediction(result)

      // Save to local storage for history
      const history = JSON.parse(localStorage.getItem("prediction_history") || "[]")
      history.unshift({
        id: Date.now(),
        timestamp: result.timestamp,
        customer_data: formData,
        prediction: result.prediction,
        recommendation: result.recommendation,
        confidence_level: result.confidence_level,
        model_used: result.model_used,
      })
      localStorage.setItem("prediction_history", JSON.stringify(history.slice(0, 100))) // Keep last 100
    } catch (err) {
      setError(err instanceof Error ? err.message : "Prediction failed")
    } finally {
      setLoading(false)
    }
  }

  const loadSampleData = async () => {
    try {
      const sampleData = await apiService.getSampleRequest()
      setFormData(sampleData.sample_customer_data)
    } catch (err) {
      // Fallback to hardcoded sample data if API call fails
      const samples = [
        {
          name: "High Quality Customer",
          data: {
            age: 35,
            income: 85000,
            employment_length: 10,
            debt_to_income_ratio: 0.2,
            credit_history_length: 15,
            number_of_credit_accounts: 4,
            payment_history_score: 780,
            credit_utilization: 0.15,
            number_of_late_payments: 0,
            loan_amount: 30000,
            home_ownership: "own",
            education_level: "bachelor",
            marital_status: "married",
          },
        },
        {
          name: "Medium Risk Customer",
          data: {
            age: 28,
            income: 45000,
            employment_length: 3,
            debt_to_income_ratio: 0.45,
            credit_history_length: 5,
            number_of_credit_accounts: 8,
            payment_history_score: 650,
            credit_utilization: 0.6,
            number_of_late_payments: 3,
            loan_amount: 20000,
            home_ownership: "rent",
            education_level: "high_school",
            marital_status: "single",
          },
        },
        {
          name: "High Risk Customer",
          data: {
            age: 22,
            income: 25000,
            employment_length: 1,
            debt_to_income_ratio: 0.8,
            credit_history_length: 2,
            number_of_credit_accounts: 12,
            payment_history_score: 520,
            credit_utilization: 0.9,
            number_of_late_payments: 8,
            loan_amount: 15000,
            home_ownership: "rent",
            education_level: "high_school",
            marital_status: "single",
          },
        },
      ]

      const randomSample = samples[Math.floor(Math.random() * samples.length)]
      setFormData(randomSample.data)
    }
  }

  const isFormDisabled = connectionStatus !== "connected" || loading

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Customer Information
          </CardTitle>
          <CardDescription>Enter customer details to assess creditworthiness</CardDescription>
        </CardHeader>
        <CardContent>
          {connectionStatus !== "connected" && (
            <Alert className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                API server is {connectionStatus}. Please ensure the backend is running to make predictions.
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <h3 className="font-semibold">Personal Information</h3>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => handleInputChange("age", e.target.value)}
                    min="18"
                    max="100"
                    disabled={isFormDisabled}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="employment_length">Employment Length (years)</Label>
                  <Input
                    id="employment_length"
                    type="number"
                    value={formData.employment_length}
                    onChange={(e) => handleInputChange("employment_length", e.target.value)}
                    min="0"
                    max="50"
                    disabled={isFormDisabled}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="marital_status">Marital Status</Label>
                  <Select
                    value={formData.marital_status}
                    onValueChange={(value) => handleInputChange("marital_status", value)}
                    disabled={isFormDisabled}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single</SelectItem>
                      <SelectItem value="married">Married</SelectItem>
                      <SelectItem value="divorced">Divorced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="education_level">Education Level</Label>
                  <Select
                    value={formData.education_level}
                    onValueChange={(value) => handleInputChange("education_level", value)}
                    disabled={isFormDisabled}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high_school">High School</SelectItem>
                      <SelectItem value="bachelor">Bachelor's Degree</SelectItem>
                      <SelectItem value="master">Master's Degree</SelectItem>
                      <SelectItem value="phd">PhD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            {/* Financial Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                <h3 className="font-semibold">Financial Information</h3>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="income">Annual Income ($)</Label>
                  <Input
                    id="income"
                    type="number"
                    value={formData.income}
                    onChange={(e) => handleInputChange("income", e.target.value)}
                    min="0"
                    disabled={isFormDisabled}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="loan_amount">Loan Amount ($)</Label>
                  <Input
                    id="loan_amount"
                    type="number"
                    value={formData.loan_amount}
                    onChange={(e) => handleInputChange("loan_amount", e.target.value)}
                    min="0"
                    disabled={isFormDisabled}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="debt_to_income_ratio">Debt-to-Income Ratio</Label>
                <Input
                  id="debt_to_income_ratio"
                  type="number"
                  step="0.01"
                  value={formData.debt_to_income_ratio}
                  onChange={(e) => handleInputChange("debt_to_income_ratio", e.target.value)}
                  min="0"
                  max="5"
                  disabled={isFormDisabled}
                  required
                />
              </div>
            </div>

            <Separator />

            {/* Credit Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <h3 className="font-semibold">Credit Information</h3>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="payment_history_score">Credit Score</Label>
                  <Input
                    id="payment_history_score"
                    type="number"
                    value={formData.payment_history_score}
                    onChange={(e) => handleInputChange("payment_history_score", e.target.value)}
                    min="300"
                    max="850"
                    disabled={isFormDisabled}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="credit_history_length">Credit History Length (years)</Label>
                  <Input
                    id="credit_history_length"
                    type="number"
                    value={formData.credit_history_length}
                    onChange={(e) => handleInputChange("credit_history_length", e.target.value)}
                    min="0"
                    max="50"
                    disabled={isFormDisabled}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="number_of_credit_accounts">Number of Credit Accounts</Label>
                  <Input
                    id="number_of_credit_accounts"
                    type="number"
                    value={formData.number_of_credit_accounts}
                    onChange={(e) => handleInputChange("number_of_credit_accounts", e.target.value)}
                    min="0"
                    max="50"
                    disabled={isFormDisabled}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="number_of_late_payments">Late Payments</Label>
                  <Input
                    id="number_of_late_payments"
                    type="number"
                    value={formData.number_of_late_payments}
                    onChange={(e) => handleInputChange("number_of_late_payments", e.target.value)}
                    min="0"
                    disabled={isFormDisabled}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="credit_utilization">Credit Utilization Ratio</Label>
                <Input
                  id="credit_utilization"
                  type="number"
                  step="0.01"
                  value={formData.credit_utilization}
                  onChange={(e) => handleInputChange("credit_utilization", e.target.value)}
                  min="0"
                  max="5"
                  disabled={isFormDisabled}
                  required
                />
              </div>
            </div>

            <Separator />

            {/* Housing Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                <h3 className="font-semibold">Housing Information</h3>
              </div>

              <div>
                <Label htmlFor="home_ownership">Home Ownership</Label>
                <Select
                  value={formData.home_ownership}
                  onValueChange={(value) => handleInputChange("home_ownership", value)}
                  disabled={isFormDisabled}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rent">Rent</SelectItem>
                    <SelectItem value="own">Own</SelectItem>
                    <SelectItem value="mortgage">Mortgage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={isFormDisabled} className="flex-1">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Analyze Creditworthiness"
                )}
              </Button>
              <Button type="button" variant="outline" onClick={loadSampleData} disabled={loading}>
                Load Sample
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="space-y-6">
        {error && (
          <Alert className="border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-600">{error}</AlertDescription>
          </Alert>
        )}

        {prediction && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {prediction.prediction.creditworthy ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                Credit Assessment Result
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Main Result */}
              <div className="text-center">
                <Badge
                  variant={prediction.prediction.creditworthy ? "default" : "destructive"}
                  className="text-lg px-4 py-2"
                >
                  {prediction.prediction.creditworthy ? "CREDITWORTHY" : "NOT CREDITWORTHY"}
                </Badge>
                <div className="mt-2">
                  <Badge variant="outline" className="text-sm">
                    {prediction.confidence_level} Confidence
                  </Badge>
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {(prediction.prediction.probability_creditworthy * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Creditworthy Probability</div>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {(prediction.prediction.risk_score * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Risk Score</div>
                </div>
              </div>

              {/* Recommendation */}
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Recommendation:</strong> {prediction.recommendation}
                </AlertDescription>
              </Alert>

              {/* Model Info */}
              <div className="text-sm text-gray-500 space-y-1">
                <p>Model used: {prediction.model_used.replace("_", " ").toUpperCase()}</p>
                <p>Analysis completed: {new Date(prediction.timestamp).toLocaleString()}</p>
              </div>

              {/* Confidence Indicator */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Confidence Level</span>
                  <span>
                    {(
                      Math.max(
                        prediction.prediction.probability_creditworthy,
                        prediction.prediction.probability_not_creditworthy,
                      ) * 100
                    ).toFixed(1)}
                    %
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.max(prediction.prediction.probability_creditworthy, prediction.prediction.probability_not_creditworthy) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tips Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Assessment Tips</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-600">
            <p>• Higher credit scores (750+) significantly improve approval chances</p>
            <p>• Keep debt-to-income ratio below 0.4 for better assessment</p>
            <p>• Longer credit history demonstrates financial stability</p>
            <p>• Lower credit utilization (&lt;30%) is preferred</p>
            <p>• Stable employment history strengthens the application</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
export type { CustomerData, CreditScoringFormProps }
export { CreditScoringForm }