"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { History, Search, Filter, Download, Trash2, CheckCircle, XCircle } from "lucide-react"

interface PredictionRecord {
  id: number
  timestamp: string
  customer_data: any
  prediction: {
    creditworthy: boolean
    probability_creditworthy: number
    risk_score: number
  }
  recommendation: string
}

export default function PredictionHistory() {
  const [history, setHistory] = useState<PredictionRecord[]>([])
  const [filteredHistory, setFilteredHistory] = useState<PredictionRecord[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("newest")

  useEffect(() => {
    loadHistory()
  }, [])

  useEffect(() => {
    filterAndSortHistory()
  }, [history, searchTerm, filterStatus, sortBy])

  const loadHistory = () => {
    const stored = localStorage.getItem("prediction_history")
    if (stored) {
      try {
        const parsed = JSON.parse(stored)
        setHistory(parsed)
      } catch (error) {
        console.error("Error parsing history:", error)
        setHistory([])
      }
    }
  }

  const filterAndSortHistory = () => {
    let filtered = [...history]

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (record) =>
          record.id.toString().includes(searchTerm) ||
          record.customer_data.age?.toString().includes(searchTerm) ||
          record.customer_data.income?.toString().includes(searchTerm),
      )
    }

    // Apply status filter
    if (filterStatus !== "all") {
      filtered = filtered.filter((record) => {
        if (filterStatus === "creditworthy") return record.prediction.creditworthy
        if (filterStatus === "not_creditworthy") return !record.prediction.creditworthy
        return true
      })
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        case "oldest":
          return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
        case "highest_confidence":
          return b.prediction.probability_creditworthy - a.prediction.probability_creditworthy
        case "lowest_confidence":
          return a.prediction.probability_creditworthy - b.prediction.probability_creditworthy
        default:
          return 0
      }
    })

    setFilteredHistory(filtered)
  }

  const clearHistory = () => {
    if (confirm("Are you sure you want to clear all prediction history?")) {
      localStorage.removeItem("prediction_history")
      setHistory([])
    }
  }

  const exportHistory = () => {
    const dataStr = JSON.stringify(history, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)

    const exportFileDefaultName = `prediction_history_${new Date().toISOString().split("T")[0]}.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleString()
  }

  const getStatusBadge = (creditworthy: boolean) => {
    return creditworthy ? (
      <Badge variant="default" className="flex items-center gap-1">
        <CheckCircle className="h-3 w-3" />
        Creditworthy
      </Badge>
    ) : (
      <Badge variant="destructive" className="flex items-center gap-1">
        <XCircle className="h-3 w-3" />
        Not Creditworthy
      </Badge>
    )
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-green-600"
    if (confidence >= 0.6) return "text-yellow-600"
    return "text-red-600"
  }

  return (
<div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Prediction History
              </CardTitle>
              <CardDescription>View and manage past credit scoring predictions</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={exportHistory} variant="outline" size="sm" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <Button onClick={clearHistory} variant="outline" size="sm" className="flex items-center gap-2">
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                placeholder="Search by ID, age, or income..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Results</SelectItem>
                <SelectItem value="creditworthy">Creditworthy</SelectItem>
                <SelectItem value="not_creditworthy">Not Creditworthy</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="highest_confidence">Highest Confidence</SelectItem>
                <SelectItem value="lowest_confidence">Lowest Confidence</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Summary Stats */}
          {history.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold">{history.length}</div>
                <div className="text-sm text-gray-600">Total Predictions</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  {history.filter((h) => h.prediction.creditworthy).length}
                </div>
                <div className="text-sm text-green-700">Creditworthy</div>
              </div>
              <div className="text-center p-3 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">
                  {history.filter((h) => !h.prediction.creditworthy).length}
                </div>
                <div className="text-sm text-red-700">Not Creditworthy</div>
              </div>
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">
                  {history.length > 0
                    ? (
                        (history.reduce((sum, h) => sum + h.prediction.probability_creditworthy, 0) / history.length) *
                        100
                      ).toFixed(1) + "%"
                    : "0%"}
                </div>
                <div className="text-sm text-blue-700">Avg Confidence</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* History Table */}
      {filteredHistory.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Customer Info</TableHead>
                    <TableHead>Result</TableHead>
                    <TableHead>Confidence</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead>Recommendation</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">
                        <div className="text-sm">{formatDate(record.timestamp)}</div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>Age: {record.customer_data.age}</div>
                          <div>Income: ${record.customer_data.income?.toLocaleString()}</div>
                          <div>Credit Score: {record.customer_data.payment_history_score}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(record.prediction.creditworthy)}</TableCell>
                      <TableCell>
                        <span
                          className={`font-semibold ${getConfidenceColor(record.prediction.probability_creditworthy)}`}
                        >
                          {(record.prediction.probability_creditworthy * 100).toFixed(1)}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="font-semibold text-red-600">
                          {(record.prediction.risk_score * 100).toFixed(1)}%
                        </span>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate text-sm" title={record.recommendation}>
                          {record.recommendation}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Predictions Yet</h3>
            <p className="text-gray-600 mb-4">
              {history.length === 0
                ? "Start making predictions to see your history here."
                : "No predictions match your current filters."}
            </p>
            {history.length === 0 && (
              <Button onClick={() => (window.location.hash = "#predict")}>Make Your First Prediction</Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
export type { PredictionRecord }
export { PredictionHistory }