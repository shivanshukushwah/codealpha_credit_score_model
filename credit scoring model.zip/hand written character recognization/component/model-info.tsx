"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, BarChart3, Settings, Info } from "lucide-react"

interface ModelInfo {
  model_type: string
  features_count: number
  feature_names: string[]
  feature_importance?: Record<string, number>
}

interface ModelInfoProps {
  modelInfo: ModelInfo | null
}

export default function ModelInfo({ modelInfo }: ModelInfoProps) {
  if (!modelInfo) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5" />
            Model Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">No model information available</p>
        </CardContent>
      </Card>
    )
  }

  const getModelDescription = (modelType: string) => {
    switch (modelType) {
      case "logistic_regression":
        return "A linear model that uses logistic function to model binary outcomes. Good for interpretability and understanding feature relationships."
      case "random_forest":
        return "An ensemble method that combines multiple decision trees. Excellent for handling complex patterns and providing feature importance."
      case "decision_tree":
        return "A tree-like model that makes decisions based on feature values. Highly interpretable but can overfit."
      default:
        return "Machine learning model for credit scoring predictions."
    }
  }

  const getModelStrengths = (modelType: string) => {
    switch (modelType) {
      case "logistic_regression":
        return [
          "Fast training and prediction",
          "Highly interpretable",
          "Good baseline performance",
          "Handles linear relationships well",
        ]
      case "random_forest":
        return [
          "Handles non-linear patterns",
          "Provides feature importance",
          "Robust to outliers",
          "Good generalization",
        ]
      case "decision_tree":
        return [
          "Highly interpretable",
          "Handles categorical features well",
          "No need for feature scaling",
          "Easy to visualize",
        ]
      default:
        return ["Machine learning capabilities", "Automated predictions"]
    }
  }

  // Sort features by importance if available
  const sortedFeatures = modelInfo.feature_importance
    ? Object.entries(modelInfo.feature_importance)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10) // Top 10 features
    : []

  return (
    <div className="space-y-6">
      {/* Model Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Model Overview
          </CardTitle>
          <CardDescription>Current active model information and specifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Model Type</h3>
              <Badge variant="default" className="text-lg px-3 py-1">
                {modelInfo.model_type.replace("_", " ").toUpperCase()}
              </Badge>
              <p className="text-sm text-gray-600 mt-2">{getModelDescription(modelInfo.model_type)}</p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Features</h3>
              <div className="text-2xl font-bold text-blue-600">{modelInfo.features_count}</div>
              <p className="text-sm text-gray-600">Input features used for prediction</p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Model Strengths</h3>
            <ul className="space-y-1">
              {getModelStrengths(modelInfo.model_type).map((strength, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                  {strength}
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Feature Importance */}
      {sortedFeatures.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Feature Importance
            </CardTitle>
            <CardDescription>Top features that influence the model's predictions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedFeatures.map(([feature, importance], index) => (
                <div key={feature} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">
                      {index + 1}. {feature.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                    </span>
                    <span className="text-sm text-gray-500">{(importance * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={importance * 100} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            All Features
          </CardTitle>
          <CardDescription>Complete list of features used by the model</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {modelInfo.feature_names.map((feature, index) => (
              <Badge key={index} variant="outline" className="justify-start">
                {feature.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Model Performance Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Guidelines</CardTitle>
          <CardDescription>Understanding model predictions and recommendations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-green-600 mb-2">High Confidence Approval (80%+ probability)</h4>
            <p className="text-sm text-gray-600">
              Customer shows strong creditworthiness indicators. Recommended for standard approval process.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-yellow-600 mb-2">Moderate Confidence (60-80% probability)</h4>
            <p className="text-sm text-gray-600">
              Customer shows mixed indicators. Consider additional verification or modified terms.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-red-600 mb-2">Low Confidence (&lt;60% probability)</h4>
            <p className="text-sm text-gray-600">
              Customer shows concerning risk factors. Recommend manual review or rejection.
            </p>
          </div>

          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Important Note</h4>
            <p className="text-sm text-blue-800">
              This model provides decision support and should be used alongside human judgment and regulatory compliance
              requirements.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
export type { ModelInfo, ModelInfoProps } from "./types"
export { ModelInfo } from "./model-info"