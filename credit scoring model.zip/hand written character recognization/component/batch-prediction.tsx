"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, Download, Users, CheckCircle, XCircle, AlertCircle, Loader2 } from "lucide-react"
import { apiService, type BatchPredictionResult } from "@/lib/api-service"

interface BatchPredictionProps {
  connectionStatus: "connected" | "disconnected" | "checking"
}

export default function BatchPrediction({ connectionStatus }: BatchPredictionProps) {
  const [jsonInput, setJsonInput] = useState("")
  const [results, setResults] = useState<BatchPredictionResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const sampleData = `[
  {
    "age": 35,
    "income": 75000,
    "employment_length": 8,
    "debt_to_income_ratio": 0.3,
    "credit_history_length": 12,
    "number_of_credit_accounts": 5,
    "payment_history_score": 720,
    "credit_utilization": 0.25,
    "number_of_late_payments": 1,
    "loan_amount": 25000,
    "home_ownership": "own",
    "education_level": "bachelor",
    "marital_status": "married"
  },
  {
    "age": 28,
    "income": 45000,
    "employment_length": 3,
    "debt_to_income_ratio": 0.45,
    "credit_history_length": 5,
    "number_of_credit_accounts": 8,
    "payment_history_score": 650,
    "credit_utilization": 0.6,
    "number_of_late_payments": 3,
    "loan_amount": 20000,
    "home_ownership": "rent",
    "education_level": "high_school",
    "marital_status": "single"
  },
  {
    "age": 22,
    "income": 25000,
    "employment_length": 1,
    "debt_to_income_ratio": 0.8,
    "credit_history_length": 2,
    "number_of_credit_accounts": 12,
    "payment_history_score": 520,
    "credit_utilization": 0.9,
    "number_of_late_payments": 8,
    "loan_amount": 15000,
    "home_ownership": "rent",
    "education_level": "high_school",
    "marital_status": "single"
  }
]`

  const handleSubmit = async () => {
    if (!jsonInput.trim()) {
      setError("Please enter customer data")
      return
    }

    if (connectionStatus !== "connected") {
      setError("Cannot make predictions: API server is not connected")
      return
    }

    try {
      setLoading(true)
      setError(null)
      setResults(null)

      const customerData = JSON.parse(jsonInput)
      if (!Array.isArray(customerData)) {
        throw new Error("Data must be an array of customer objects")
      }

      if (customerData.length > 1000) {
        throw new Error("Batch size too large. Maximum 1000 records allowed.")
      }

      const result = await apiService.batchPredict(customerData)
      setResults(result)
    } catch (err) {
      if (err instanceof SyntaxError) {
        setError("Invalid JSON format. Please check your input.")
      } else {
        setError(err instanceof Error ? err.message : "Batch prediction failed")
      }
    } finally {
      setLoading(false)
    }
  }

  const loadSampleData = () => {
    setJsonInput(sampleData)
  }

  const downloadResults = () => {
    if (!results) return

    const dataStr = JSON.stringify(results, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)

    const exportFileDefaultName = `batch_predictions_${new Date().toISOString().split("T")[0]}.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const getStatusIcon = (result: BatchPredictionResult["predictions"][0]) => {
    if (result.error) {
      return <XCircle className="h-4 w-4 text-red-500" />
    }
    if (result.prediction?.creditworthy) {
      return <CheckCircle className="h-4 w-4 text-green-500" />
    }
    return <XCircle className="h-4 w-4 text-red-500" />
  }

  const getStatusBadge = (result: BatchPredictionResult["predictions"][0]) => {
    if (result.error) {
      return <Badge variant="destructive">Error</Badge>
    }
    if (result.prediction?.creditworthy) {
      return <Badge variant="default">Creditworthy</Badge>
    }
    return <Badge variant="destructive">Not Creditworthy</Badge>
  }

  const isDisabled = connectionStatus !== "connected" || loading

  return (
<div className="space-y-6">
      {/* Input Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Batch Credit Assessment
          </CardTitle>
          <CardDescription>Upload multiple customer records for bulk creditworthiness analysis</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {connectionStatus !== "connected" && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                API server is {connectionStatus}. Please ensure the backend is running to make predictions.
              </AlertDescription>
            </Alert>
          )}

          <div>
            <label htmlFor="json-input" className="block text-sm font-medium mb-2">
              Customer Data (JSON Array)
            </label>
            <Textarea
              id="json-input"
              placeholder="Enter JSON array of customer data..."
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              rows={12}
              className="font-mono text-sm"
              disabled={isDisabled}
            />
          </div>

          <div className="flex gap-4">
            <Button onClick={handleSubmit} disabled={isDisabled} className="flex items-center gap-2">
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  Analyze Batch
                </>
              )}
            </Button>
            <Button variant="outline" onClick={loadSampleData} disabled={loading}>
              Load Sample Data
            </Button>
          </div>

          {error && (
            <Alert className="border-red-200">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Results Section */}
      {results && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Batch Results</CardTitle>
                <CardDescription>
                  Processed {results.summary.total_processed} records using{" "}
                  {results.model_used.replace("_", " ").toUpperCase()} ({results.summary.success_rate.toFixed(1)}%
                  success rate)
                </CardDescription>
              </div>
              <Button onClick={downloadResults} variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download Results
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{results.summary.total_processed}</div>
                <div className="text-sm text-blue-700">Total Processed</div>
              </div>

              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{results.summary.successful_predictions}</div>
                <div className="text-sm text-green-700">Successful</div>
              </div>

              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{results.summary.failed_predictions}</div>
                <div className="text-sm text-red-700">Failed</div>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-600">{results.summary.success_rate.toFixed(1)}%</div>
                <div className="text-sm text-gray-700">Success Rate</div>
              </div>
            </div>

            {/* Results Table */}
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Result</TableHead>
                    <TableHead>Confidence</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead>Recommendation</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {results.predictions.map((result) => (
                    <TableRow key={result.customer_id}>
                      <TableCell className="font-medium">{result.customer_id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">{getStatusIcon(result)}</div>
                      </TableCell>
                      <TableCell>{getStatusBadge(result)}</TableCell>
                      <TableCell>
                        {result.prediction
                          ? `${(result.prediction.probability_creditworthy * 100).toFixed(1)}%`
                          : "N/A"}
                      </TableCell>
                      <TableCell>
                        {result.prediction ? `${(result.prediction.risk_score * 100).toFixed(1)}%` : "N/A"}
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate" title={result.recommendation || result.error}>
                          {result.recommendation || result.error || "N/A"}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-gray-600">
          <p>
            <strong>JSON Format:</strong> Provide an array of customer objects with all required fields.
          </p>
          <p>
            <strong>Required Fields:</strong> age, income, employment_length, debt_to_income_ratio,
            credit_history_length, number_of_credit_accounts, payment_history_score, credit_utilization,
            number_of_late_payments, loan_amount, home_ownership, education_level, marital_status
          </p>
          <p>
            <strong>Batch Limits:</strong> Maximum 1000 records per batch for optimal performance.
          </p>
          <p>
            <strong>Processing:</strong> Each record is processed independently. Errors in individual records won't
            affect others.
          </p>
          <p>
            <strong>Download:</strong> Results can be downloaded as JSON for further analysis or record keeping.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
